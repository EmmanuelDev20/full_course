def saludar(nombre, edad):
  print("Hola ", nombre, " tienes ", edad, " años")

saludar("Emmanuel", 25)
saludar("Luis", 30)
saludar("Aiden", 22)
saludar("Gustavo", 28)
saludar("Kimberly", 27)

# Este programa suma dos números ingresados por el usuario
# a = int(input("Ingrese el primer número: "))
# b = int(input("Ingrese el segundo número: "))
# c = input("Ingrese el operador: ")

# if c == '+':
#     suma = a + b
# elif c == '-':
#     suma = a - b
# elif c == '*':
#     suma = a * b
# elif c == '/':
#     suma = a / b
# else:
#     suma = "Operador no válido"


# precio = 300
# impuesto = 0.13







# Operaciones matemáticas
# # # x = 10
# # # y = 3
# # # print("Suma:", x + y)
# # # print("Resta:" , x - y)
# # # print("Multiplicación:", x * y)
# # # print("División:", x / y)
# # # print("Módulo:", x % y)
# # # # Comparaciones
# # # print ("Es mayor?", x > y)
# # # print("Es igual?", x == y)






# # # # Comentarios 
# # # """
# # # Comentarios multilinea
# # # """
# # # print('Hola')

# # # # Variables. NO es necesario definir el tipo de dato.
# # # name = "Emmanuel" # Comentario a este lado
# # # nombre_completo = "Emmanuel Ovares Lobo"

# # # # Cómo saber el tipo de dato. Son tipos dinámicos
# # # # type(name)

# # # # Tipos de datos
# # # # Strings
# # # name2 = "Emmanuel"
# # # # Integers
# # # number = 100_000_000 # 100000000 - Esto es valido
# # # number2 = 2

# # # # Floats
# # # pi = 3.14

# # # # Booleans
# # # verdadero = True
# # # falso = False

# # # # Constantes. Se ponen en mayúsculas, pero en realidad es una variable en Python
# # # VERSION = 3.14

# # # # Enteros
# # # number = 10
# # # result = number + 10
# # # result2 = number // 10
# result = number / 10 # División flotante
# result = number // 10 # División entera
# result = number ** 2 # Potencia
# result = number % 3 # Módulo

# Operadores para comparación
# result = number == 10
# result = number != 10
# result = number > 10
# result = number < 10
# result = number >= 10
# result = number <= 10

# Tipo de dato
# type(result)

# Operadores lógicos 
# and, or, not
# result = True and True
# print(not not not result)

# Estructuras de control
# if, elif, else
# if result:
#     print('Es verdadero')
# elif result2:
#     print('elif')
# else:
#     print('Es falso')

# Consultar datos al usuario
# name = input('Ingresa tu nombre: ') # str
# age = int(input('Ingresa tu edad: ')) # int
# height = float(input('Ingresa tu altura: ')) # float
# status = input('Tu usuario se encuentra activo? (yes/no): ') == 'yes' # bool

# Definir y asignar variables
# first_name, age, is_active = "Cody", 13, True
# print(age)

# print(type(status), status)

